--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE market;
--
-- Name: market; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE market WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Russian_Russia.1251';


ALTER DATABASE market OWNER TO postgres;

\connect market

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: advert; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.advert (
    id integer NOT NULL,
    title character varying NOT NULL,
    description character varying,
    "totalPrice" character varying NOT NULL,
    status character varying NOT NULL,
    user_id integer NOT NULL,
    posted timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.advert OWNER TO postgres;

--
-- Name: advert_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.advert_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.advert_id_seq OWNER TO postgres;

--
-- Name: advert_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.advert_id_seq OWNED BY public.advert.id;


--
-- Name: reply; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reply (
    id integer NOT NULL,
    message character varying NOT NULL,
    price integer NOT NULL,
    user_id integer NOT NULL,
    advert_id integer NOT NULL
);


ALTER TABLE public.reply OWNER TO postgres;

--
-- Name: reply_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reply_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reply_id_seq OWNER TO postgres;

--
-- Name: reply_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reply_id_seq OWNED BY public.reply.id;


--
-- Name: userss; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.userss (
    id integer NOT NULL,
    email character varying NOT NULL,
    password character varying NOT NULL,
    first_name character varying,
    last_name character varying,
    username character varying NOT NULL
);


ALTER TABLE public.userss OWNER TO postgres;

--
-- Name: userss_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.userss_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.userss_id_seq OWNER TO postgres;

--
-- Name: userss_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.userss_id_seq OWNED BY public.userss.id;


--
-- Name: advert id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advert ALTER COLUMN id SET DEFAULT nextval('public.advert_id_seq'::regclass);


--
-- Name: reply id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reply ALTER COLUMN id SET DEFAULT nextval('public.reply_id_seq'::regclass);


--
-- Name: userss id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userss ALTER COLUMN id SET DEFAULT nextval('public.userss_id_seq'::regclass);


--
-- Data for Name: advert; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3333.dat

--
-- Data for Name: reply; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3335.dat

--
-- Data for Name: userss; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3331.dat

--
-- Name: advert_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.advert_id_seq', 1, false);


--
-- Name: reply_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reply_id_seq', 1, false);


--
-- Name: userss_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.userss_id_seq', 2, true);


--
-- Name: advert advert_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advert
    ADD CONSTRAINT advert_pkey PRIMARY KEY (id);


--
-- Name: userss email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userss
    ADD CONSTRAINT email_unique UNIQUE (email);


--
-- Name: reply reply_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reply
    ADD CONSTRAINT reply_pkey PRIMARY KEY (id);


--
-- Name: userss username_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userss
    ADD CONSTRAINT username_unique UNIQUE (username);


--
-- Name: userss userss_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userss
    ADD CONSTRAINT userss_pkey PRIMARY KEY (id);


--
-- Name: advert advert_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.advert
    ADD CONSTRAINT advert_user FOREIGN KEY (user_id) REFERENCES public.userss(id);


--
-- Name: reply reply_advert; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reply
    ADD CONSTRAINT reply_advert FOREIGN KEY (advert_id) REFERENCES public.advert(id) NOT VALID;


--
-- Name: reply reply_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reply
    ADD CONSTRAINT reply_user FOREIGN KEY (user_id) REFERENCES public.userss(id) NOT VALID;


--
-- PostgreSQL database dump complete
--

